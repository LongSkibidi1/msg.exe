 _  _  ____   ___     ____  _  _  ____       
( \/ )/ ___) / __)   (  __)( \/ )(  __)      
/ \/ \\___ \( (_ \ _  ) _)  )  (  ) _)       
\_)(_/(____/ \___/(_)(____)(_/\_)(____)      

Made by LongSkibidi1

This is a malware (have x64 and x86)

Thanks for read!